var class_nex_crop =
[
    [ "NexCrop", "class_nex_crop.html#a1a3a195d3da05cb832f91a2ef43f27d3", null ],
    [ "getPic", "class_nex_crop.html#a2cbfe125182626965dd530f14ab55885", null ],
    [ "setPic", "class_nex_crop.html#aac34fc2f8ead1e330918089ea8a339db", null ]
];