var class_nex_slider =
[
    [ "NexSlider", "class_nex_slider.html#a00c5678209c936e9a57c14b6e2384774", null ],
    [ "getValue", "class_nex_slider.html#a384d5488b421efd6affbfd32f45bb107", null ],
    [ "setValue", "class_nex_slider.html#a3f325bda4db913e302e94a4b25de7b5f", null ]
];